<template>
  <div class="home-container">
    <div class="home-text">首页</div>
    具体样式根据项目实现
  </div>
</template>

<script>
export default {
  name: 'Home'
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.home {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
