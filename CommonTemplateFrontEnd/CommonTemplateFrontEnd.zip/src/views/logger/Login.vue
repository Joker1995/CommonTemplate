<template>
  <div class="app-container">
    具体实现看项目
  </div>
</template>
<script>
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.app-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
}
</style>
